#include<iostream>
#include<cmath>
#include<conio.h>
#include<string>
#include<windows.h>

#define VERSIONE "0.1v"

#define CLS system("cls");    //Macro per velocizzare la scrittura del codice
#define PAUSE system("pause");

using namespace std;

char scelta();
void stampaMenu();
bool is_number(const string &);

int main()
{
    string Ix, Iy;   //Stringhe di input
    double x, y;     //Variabili per il calcolo
    double ans = 0;  //Risultato
    CLS
    stampaMenu();
    bool cont = true;

    while(cont)
    {
        char s = scelta();
        CLS
        switch(s)
        {
            case '1':{
                cout<<"inserisci primo operando: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                cout<<x<<" + ";
                getline(cin,Iy);
                while(true)
                {
                    if(is_number(Iy))
                    {
                        y = stod(Iy);
                        break;
                    }
                    else if(Iy == "ans")
                    {
                        y = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Iy);
                    }
                }
                ans = x + y;
                CLS
                cout<<x<<" + "<<y<<" = "<<ans<<endl;
                PAUSE
            break;}

            case '2':{
                cout<<"inserisci primo operando: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Iy);
                    }
                }
                CLS
                cout<<x<<" - ";
                getline(cin,Iy);
                while(true)
                {
                    if(is_number(Iy))
                    {
                        y = stod(Iy);
                        break;
                    }
                    else if(Iy == "ans")
                    {
                        y = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Iy);
                    }
                }
                ans = x - y;
                CLS
                cout<<x<<" - "<<y<<" = "<<ans<<endl;
                PAUSE
            break;}

            case '3':{
                cout<<"inserisci primo operando: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                cout<<x<<" x ";
                getline(cin,Iy);
                while(true)
                {
                    if(is_number(Iy))
                    {
                        y = stod(Iy);
                        break;
                    }
                    else if(Iy == "ans")
                    {
                        y = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Iy);
                    }
                }
                ans = x * y;
                CLS
                cout<<x<<" x "<<y<<" = "<<ans<<endl;
                PAUSE
            break;}

            case '4':{
                cout<<"inserisci primo operando: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                cout<<x<<" : ";
                getline(cin,Iy);
                while(true)
                {
                    if(is_number(Iy))
                    {
                        y = stod(Iy);
                        break;
                    }
                    else if(Iy == "ans")
                    {
                        y = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Iy);
                    }
                }
                if(y == 0)
                {
                    cout<<"errore"<<endl;
                }
                else
                {
                    ans = x / y;
                    cout<<x<<" : "<<y<<" = "<<ans<<endl;
                    PAUSE
                }

                CLS

                PAUSE
            break;}

            case '5':{
                cout<<"inserisci primo operando: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                cout<<x<<" ^( ";
                getline(cin,Iy);
                while(true)
                {
                    if(is_number(Iy))
                    {
                        y = stod(Iy);
                        break;
                    }
                    else if(Iy == "ans")
                    {
                        y = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Iy);
                    }
                }
                ans = pow(x,y);
                CLS
                cout<<x<<" ^( "<<y<<" ) = "<<ans<<endl;
                PAUSE
            break;}

            case '6':{
                cout<<"inserisci primo operando: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                cout<<x<<" ^1/( ";
                getline(cin,Iy);
                while(true)
                {
                    if(is_number(Iy))
                    {
                        y = stod(Iy);
                        break;
                    }
                    else if(Iy == "ans")
                    {
                        y = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci primo operando: ";
                        getline(cin,Iy);
                    }
                }
                ans = pow(x,1.0/y);
                CLS
                cout<<x<<" ^1/( "<<y<<" ) = "<<ans<<endl;
                PAUSE
            break;}

            case 'a':{
                cout<<"inserisci gradi: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci gradi: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                ans = sin(x * (M_PI / 180.0));
                cout<<"sin("<<x<<") = "<<ans<<endl;
                PAUSE
            break;}

            case 'b':{
                cout<<"inserisci gradi: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci gradi: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                ans = cos(x * (M_PI / 180.0));
                cout<<"cos("<<x<<") = "<<ans<<endl;
                PAUSE
            break;}

            case 'c':{
                cout<<"inserisci gradi: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci gradi: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                ans = tan(x * (M_PI / 180.0));
                cout<<"tan("<<x<<") = "<<ans<<endl;
                PAUSE
            break;}

            case 'd':{
                cout<<"inserisci sin x: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci sin x: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                if(isnan(asin(x)))
                {
                    cout<<"errore"<<endl;
                }
                else
                {
                    ans = asin(x);
                    cout<<"arcsin("<<x<<") = "<<ans<<endl;
                }

                PAUSE
            break;}

            case 'e':{
                cout<<"inserisci cos x: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci cos x: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                if(isnan(acos(x)))
                {
                    cout<<"errore"<<endl;
                }
                else
                {
                    ans = acos(x);
                    cout<<"arccos("<<x<<") = "<<ans<<endl;
                }
                PAUSE
            break;}

            case 'f':{
                cout<<"inserisci tan x: ";
                getline(cin,Ix);
                while(true)
                {
                    if(is_number(Ix))
                    {
                        x = stod(Ix);
                        break;
                    }
                    else if(Ix == "ans")
                    {
                        x = ans;
                        break;
                    }
                    else
                    {
                        CLS
                        cout<<"Numero non valido!"<<endl;
                        Sleep(1000);
                        CLS
                        cout<<"inserisci tan x: ";
                        getline(cin,Ix);
                    }
                }
                CLS
                ans = atan(x);
                cout<<"arctan("<<x<<") = "<<ans<<endl;
                PAUSE
            break;}

            case 'q':{
                return 0;
            break;}
        }
        CLS
        stampaMenu();
    }
}
void stampaMenu()
{
    cout<<" Calcolatrice semplice "<<VERSIONE<<endl<<endl;

    cout<<" 1) +"<<endl;
    cout<<" 2) -"<<endl;
    cout<<" 3) x"<<endl;
    cout<<" 4) :"<<endl<<endl;

    cout<<" 5) pow"<<endl;
    cout<<" 6) sqrt"<<endl<<endl;

    cout<<" a) sin x"<<endl;
    cout<<" b) cos x"<<endl;
    cout<<" c) tan x"<<endl;
    cout<<" d) arcsin x"<<endl;
    cout<<" e) arccos x"<<endl;
    cout<<" f) arctan x"<<endl<<endl;

    cout<<" q) esci"<<endl;
}

char scelta()
{
    char x;
    x = _getch();
    while((x < '1' || x > '6')&&(x < 'a' || x > 'f') && (x != 'q'))
    {
        x = _getch();
    }
    return x;
}

bool is_number(const string & s)
{
    try
    {
        size_t pos;
        stod(s,&pos);
    }
    catch(...){
        return false;
    }
    return true;
}

